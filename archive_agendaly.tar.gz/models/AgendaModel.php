<?php

function createAgenda (string $name, bool $is_public, int $id_user, string $guests): void 
{
    require $_SERVER['DOCUMENT_ROOT'] . '/database/db.php';
    $sql = "INSERT INTO agendas (name, is_public, id_user, guests) VALUES (:name, :is_public, :id_user, :guests);";
    $query = $connection->prepare($sql);
    $query->bindValue(':name', $name, PDO::PARAM_STR);
    $query->bindValue(':is_public', $is_public, PDO::PARAM_BOOL);
    $query->bindValue(':id_user', $id_user, PDO::PARAM_INT);
    $query->bindValue(':guests', $guests, PDO::PARAM_STR);
    $query->execute();
    
}

function getAgendas(): array
{
    require $_SERVER['DOCUMENT_ROOT'] . '/database/db.php';
    $sql = "SELECT * FROM agendas ORDER BY created_at";
    $query = $connection->prepare($sql);
    $query->execute();
    $result = $query->fetchAll();
    return $result;
}

function getPublicAgendas(): array
{
    require $_SERVER['DOCUMENT_ROOT'] . '/database/db.php';
    $sql = "SELECT * FROM agendas WHERE is_public = 1";
    $query = $connection->prepare($sql);
    $query->execute();
    $result = $query->fetchAll();
    return $result;
}
function getPrivateAgendas(): array
{
    require $_SERVER['DOCUMENT_ROOT'] . '/database/db.php';
    $sql = "SELECT * FROM agendas WHERE is_public = 0";
    $query = $connection->prepare($sql);
    $query->execute();
    $result = $query->fetchAll();
    return $result;
}

function getAgendasByDescDate(): array
{
    require $_SERVER['DOCUMENT_ROOT'] . '/database/db.php';
    $sql = "SELECT * FROM agendas ORDER BY created_at DESC";
    $query = $connection->prepare($sql);
    $query->execute();
    $result = $query->fetchAll();
    return $result;
}


function deleteAgenda($id): array 
{
    require $_SERVER['DOCUMENT_ROOT'] . '/database/db.php';
    $sql = "DELETE FROM agendas WHERE id = $id";
    $query = $connection->prepare($sql);
    $query->execute();
    $result = $query->fetchAll();
    return $result;
}