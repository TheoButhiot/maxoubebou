<?php

require $_SERVER['DOCUMENT_ROOT'] . '/database/db.php';
