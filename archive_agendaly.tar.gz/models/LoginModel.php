<?php


function getUsers(string $email): array
{
    require $_SERVER['DOCUMENT_ROOT'] . '/database/db.php';
    $sql = "SELECT * FROM users WHERE email = :email";
    $query = $connection->prepare($sql);
    $query->bindValue(':email', $email, PDO::PARAM_STR);
    $query->execute();
    $data =  $query->fetchAll(PDO::FETCH_ASSOC);
    return $data;
}


function getUsersByRowCount(string $email)
{
    require $_SERVER['DOCUMENT_ROOT'] . '/database/db.php';
    $sql = "SELECT * FROM users WHERE email = :email";
    $query = $connection->prepare($sql);
    $query->bindValue(':email', $email, PDO::PARAM_STR);
    $query->execute();
    $row = $query->rowCount();
    return $row;
}
