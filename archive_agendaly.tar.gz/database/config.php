<?php

const CONFIG = [
    'database' => [
        'host' => '127.0.0.1',
        'user' => 'root',
        'password' => 'password',
        'dbname' => 'agendaly',
    ]
];
