<?php

require models('CreateEvent');
require models('agenda');

$id_user = $_SESSION['id'];

if (isset($_POST['name']) && !empty($_POST['name'])){

    $name = $_POST['name'];
    $is_public =(bool)$_POST['is_public'];

    $guests = '';
        if (!empty($_POST['invite'])){
            $guests = getGuests($_POST['invite']);
        }

    createAgenda($name, $is_public, $id_user, $guests);
}

require_once views('createAgenda');

