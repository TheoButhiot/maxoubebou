<?php


require './database/config.php' ;
require './database/db.php';



if(!empty($_POST['name']) && isset ($_POST['email']) && isset($_POST['password']))
{
    $name = ($_POST['name']);
    $email = ($_POST['email']);
    $password = ($_POST['password']);

    $check = $connection->prepare('SELECT name, email, password FROM users WHERE email = ?');
    $check->execute(array($email));
    $data =  $check->fetch();
    $row = $check->rowCount();

    
    if ($row == 0)
    {
        if(strlen($name) <= 100) 
        {
          if(strlen($email) <= 100)
          {
            if(filter_var($email))
            {
              if(strlen($password) <= 20)
              {
                
                $password = password_hash($password, PASSWORD_DEFAULT);
                $db_insert = $connection-> prepare('INSERT INTO users (name, email, password) VALUES(:name, :email, :password)');
                $db_insert->execute(array(
                  ':name' => $name,
                  ':password' => $password,
                  ':email' => $email,
                  
                ));
                require views ('logIn');

              }  
            } 
          } 
        } 
    } require views('logIn');
    
} else require views('signUp');

