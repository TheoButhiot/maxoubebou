<?php
require models('Home');
require models('Agenda');

if (empty($_SESSION)) {
    require views('Login');
    exit;
}

$currentPage = $_GET['page']??'1';

$filter = $_GET['filter']??"dateRecent";

$filterEvent = $_GET['filterEvent']??"dateRecent";

if ($filter == "public") {
    $agendas = getPublicAgendas();
} elseif ($filter == "private") {
    $agendas = getPrivateAgendas();
} elseif ($filter === "date-desc") {
    $agendas = getAgendasByDescDate();
} else {
    $agendas = getAgendas();
}


$filter_array = [
    'owned_agendas'         =>  ['public'       => "SELECT * FROM agendas WHERE id_user = ? AND is_public = 1",
                                'private'       => "SELECT * FROM agendas WHERE id_user = ? AND is_public = 0",
                                'dateRecent'    => "SELECT * FROM agendas WHERE id_user = ? ORDER BY created_at ASC",
                                'dateFar'       => "SELECT * FROM agendas WHERE id_user = ? ORDER BY created_at DESC"],
    'collaboratif_agendas'  =>  ['public'       => "SELECT * FROM agendas WHERE guests LIKE ? AND is_public = 1",
                                'private'       => "SELECT * FROM agendas WHERE guests LIKE ? AND is_public = 0",
                                'dateRecent'    => "SELECT * FROM agendas WHERE guests LIKE ? ORDER BY created_at ASC",
                                'dateFar'       => "SELECT * FROM agendas WHERE guests LIKE ? ORDER BY created_at DESC"]
];

$id_user = $_SESSION['id'];
$email = $_SESSION['email'];

$owned_agendas = getAgendabyID($id_user, $filter_array['owned_agendas'][$filter]);
$collaboratif_agendas = getAgendaCollaboratif($email, $filter_array['collaboratif_agendas'][$filter]);

if (!empty($_POST['submitAgenda']) || !empty($_SESSION['checkedAgendas'])) {
    
    if (!empty($_POST['submitAgenda'])) {
        
        $checked_agendas = array_keys($_POST);
        array_pop($checked_agendas);
        $_SESSION['checkedAgendas'] = $checked_agendas;
    }

    if (!empty($_SESSION['checkedAgendas'])) {
        $id_agenda ='id_agenda = ';

        foreach ($_SESSION['checkedAgendas'] as $agenda){
            $id_agenda .= $agenda.' OR id_agenda = ';
        }

        $id_agenda = rtrim($id_agenda, 'OR id_agenda =');
    }
    
    if (!empty($id_agenda)) {
        $nbPost = nbPost($id_agenda);
        $perPage = 9;
        $pages = ceil($nbPost / $perPage);
        $first = ($currentPage * $perPage) - $perPage;
        $events = getEvents($id_agenda, $filterEvent, $first, $perPage);
    }else{
        $events='';
    }
        

}
require views('Home');