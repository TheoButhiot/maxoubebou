<?php

if (!empty($_SESSION)) {
  require controllers('home');
  exit;
}

require './database/config.php';
require './database/db.php';
require_once './models/logInModel.php';

if (isset($_POST['email']) && isset($_POST['password']))
{
  
  $email = $_POST['email'];
  $password = $_POST['password'];
 
  $data = getUsers($email);
  $row = getUsersByRowCount($email);
 

  if ($row > 0)
  {
    if(filter_var($email, FILTER_VALIDATE_EMAIL))
    {   
        if (password_verify($password, $data[0]['password']))
        { 
        $_SESSION = $data[0];
        
        require controllers('home');
        exit;
        }
    }
  }
}

require views ('logIn');





