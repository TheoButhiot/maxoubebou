<?php

require_once './models/agendaModel.php';


$id = $_GET['id'];
deleteAgenda($id);

header('Location: ' . '/home');
exit;
