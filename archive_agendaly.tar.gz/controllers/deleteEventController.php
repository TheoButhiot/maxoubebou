<?php

require models('CreateEvent');

$delete_IdEvent = $_GET['id'];

deleteEvent($delete_IdEvent);

require controllers('home');