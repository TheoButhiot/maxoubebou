<?php

$config = array (
    'database' => [
        'host' => '',
        'user' => '',
        'password' => '',
        'dbname' => '',
    ]
);