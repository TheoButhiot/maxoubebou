<!DOCTYPE html>
<html lang="en">
<head>
    <meta charSet="utf-8"/>
    <meta name="viewport" content="width=device-width"/>
    <title>Erreur 404</title>
    <meta name="description" content="Blog"/>
</head>
<body>
<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>AGENDALY</title>
    <link rel="stylesheet" href="../assets/styles/error.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&family=Lato:wght@300;400;700;900&display=swap"
      rel="stylesheet"
    />
  </head>
  <body>
  <h1 data-heading="404">404</h1>
      <h3 class="subtitle-error">La page est introuvable</h3>
      <a href="/home" class="btn">Revenir à l'accueil</a>

</body>
</html>

</body>
</html>