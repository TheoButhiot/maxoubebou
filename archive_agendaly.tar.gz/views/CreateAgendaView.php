<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../assets/styles/Posts.css">
</head>
<body>
    <div class="card">
    <a href="/home" class="btn-close" aria-hidden="true">×</a>
        <h2 class="title">Créez votre agenda</h2>

        <form action="/createAgenda" method="POST">
          <label class="label-input" for="name">
            <input type="text" class="input-text" name="name" id="name" maxlength="15" placeholder="&nbsp;" />
            <span class="label">Nom</span>
          </label>
          <div class="radio-privacy">
          <div>
            <input type="radio" id="public" name="is_public" value='1'>
            <label for="public">public</label>
          </div>
          
          <div>
            <input type="radio" id="private" name="is_public" value='0' checked>
            <label for="private">privée</label>
          </div>
        </div>

          <label class="label-input">
            <input type="text" class="input-text" placeholder="&nbsp;" name="invite" />
            <span class="label">Inviter des membres</span>
          </label>
          <button type="submit" class="btn-save">Enregistrer</button>
          
        </form>

      </div>
    </div>
</body>
</html>