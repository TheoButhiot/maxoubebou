function openNav() {
    document.getElementById("sideMenu").style.left = "0px";
   }
   
   
   function closeNav() {
     document.getElementById("sideMenu").style.left = "-322px";
   }